public class Ejercicio8 {
    
        public static void main(String [] args){
        int n1 = 50, n2 = 30, suma = 0, n3;
        suma = n1 + n2;
        System.out.println("LA SUMA ES: " + suma);
        n3 = suma + suma;
        System.out.println("La suma es: " + n3);
        }
        }
