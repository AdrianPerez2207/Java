public class Ejercicio3 {

    public static void main(String[] args) {

        //a. a es mayor que 2
        //b. b es menor o igual que 25 pero mayor que 5 
        //c. c es mayor que 6 o igual a d
        //d. e es par menor que 50
        //e. f es mayor que a, b y c
        //f. g es igual a 3, 4 ó 5

        // a > 2;
        // ((b <= 25) && >5); 
        // (c < 6) || (c == d);
        // (e < 50) && (e % 2 == 0 );
        // (f > a) && (f > b) && (f > c);
        // (g == 3) || (g == 4) || (g == 5);

    }
    
}
