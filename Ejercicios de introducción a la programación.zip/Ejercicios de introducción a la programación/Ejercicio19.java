public class Ejercicio19 {

    public static void main(String[] args) {
        
        char caracter1 = 'J';
        char caracter2 = 'j';


        int Mayuscula = (int) caracter1;
        int Minuscula = (int) caracter2;
        System.out.println("El valor ASCII de J es:" + Mayuscula);
        System.out.println("El valor ASCII de j es:" + Minuscula);
    }
    
}
