public class Ejercicio20 {

    // 1.
    (5 * Math.pow(a, 2) * Math.pow(b,3)) + (Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2)));

    // 2.
    (Math.sqrt(4 * a * (Math.pow(b, 2))));

    // 3.
    ((Math.pow(a, 3) * b) / (2 * a * Math.pow (b, 2))) - (math.sqrt(12 * Math.pow(d, 4)));
    
}
