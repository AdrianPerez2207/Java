public class Ejercicio9 {

        public static void main(String [] args)
        {
         int numero=2, cuad;
         cuad =numero * numero;
         System.out.println("EL CUADRADO DE "+ numero +" ES: " + cuad);
    }
        


    
}
