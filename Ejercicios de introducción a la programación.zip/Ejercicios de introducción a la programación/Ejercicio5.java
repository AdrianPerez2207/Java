public class Ejercicio5 {

    public static void main(String[] args) {
        
        //1. No. La variable sería de texto

        //2. No. La variable sería "double"

        //3. No, la coma en Java seria "."

        //4. Sí. "Falso"

        //5. No. Tipo de variable erróneo

        //6. No. Tipo de variable erróneo



    }
    
}
