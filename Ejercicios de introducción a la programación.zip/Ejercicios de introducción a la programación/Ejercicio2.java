public class Ejercicio2 {

    public static void main(String[] args) {
        
        //Variables
        int a, b, c;
        a = 3;
        b = 4;

        //Intrucciones
        c = 2 * a * b;
        a = a + 2;
        b = c - a;
        System.out.println("c: " + c);
        System.out.println("a: " + a);
        System.out.println("b: " + b);

        //c: 24
        //a: 5
        //b: 19
    }
    
}
