public class Ejercicio18 {

    public static void main(String[] args) {
        
        int a = 10, b = 3 , e = 1, d;
        boolean c;
        c = true; 
        float x, y;
        x= a / b;
        c = a < b && c;
        d = a + b++;
        e = ++a - b;
        y = (float)a / b;


    }
    
}
