public class Ejercicio7 {

        public static void main(String [] args)
        {
        int n1=50,n2=30;
        int suma = 0;
        suma = n1+n2;
        System.out.println("LA SUMA ES: " + suma);
        }
        }
    

