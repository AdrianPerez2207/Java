public class Ejercicio4 {

    public static void main(String[] args) {

        //a: True
        //b: True
        //c: False
        //d: True
        //e: True
    }
    
}
